<?php

$img = '';




echo 'data:image/svg+xml;base64,'.base64_encode($img);