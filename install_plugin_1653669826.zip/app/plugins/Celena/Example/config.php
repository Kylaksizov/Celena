<?php

return [

    "param1" => "Значение 1",

    "param2" => "Значение 2",

    "key" => "XXXXX"

];